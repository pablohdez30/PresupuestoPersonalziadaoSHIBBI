// ─────────────────────────────────────────────────────────────────
// Panel de precio sticky — el elemento más importante visualmente.
// Lateral derecho en desktop, banda inferior expandible en móvil.
// ─────────────────────────────────────────────────────────────────

const { useState: useStateP, useEffect: useEffectP, useMemo: useMemoP } = React;

function PricePanel({ config, layout = "right-sticky" }) {
  const { total, desglose } = useMemoP(() => calcularEstimacion(config), [config]);

  const empty = desglose.length === 0;

  return (
    <aside
      className={`price-panel layout-${layout}`}
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border-soft)",
        boxShadow: "0 1px 0 rgba(0,0,0,0.04)",
        padding: "28px 28px 32px",
      }}
    >
      <div className="eyebrow" style={{ marginBottom: 20 }}>
        Tu mueble
      </div>
      <div style={{ borderTop: "1px solid var(--border-soft)" }} />

      <div style={{ minHeight: 120, padding: "20px 0", display: "flex", flexDirection: "column", gap: 18 }}>
        {empty && (
          <div style={{ fontSize: 13, color: "var(--text-muted)", lineHeight: 1.5 }}>
            Empieza a configurar y verás aquí el desglose en vivo.
          </div>
        )}
        {desglose.map((item) => (
          <PriceLine key={item.id} item={item} />
        ))}
      </div>

      <div style={{ borderTop: "1px solid var(--border-soft)" }} />

      <div style={{ paddingTop: 20 }}>
        <div className="eyebrow" style={{ marginBottom: 8 }}>Estimación</div>
        <div
          className="display"
          style={{
            fontSize: 48,
            lineHeight: 1.1,
            letterSpacing: "-0.02em",
            display: "flex",
            alignItems: "baseline",
            gap: 4,
          }}
        >
          <span>{formatEUR(total, { decimals: 0 })}</span>
          <span style={{ fontSize: "60%", color: "var(--text-muted)" }}>€</span>
        </div>
        <div
          style={{
            fontSize: 12,
            color: "var(--text-muted)",
            marginTop: 16,
            lineHeight: 1.5,
          }}
        >
          Estimación orientativa. Confirmamos el precio final tras revisar tu solicitud.
        </div>
      </div>
    </aside>
  );
}

function PriceLine({ item }) {
  const [show, setShow] = useStateP(false);
  useEffectP(() => {
    const t = setTimeout(() => setShow(true), 20);
    return () => clearTimeout(t);
  }, []);
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "baseline",
        gap: 12,
        opacity: show ? 1 : 0,
        transform: show ? "translateY(0)" : "translateY(4px)",
        transition: "opacity 200ms ease, transform 200ms ease",
      }}
    >
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 400 }}>{item.titulo}</div>
        {item.subtitulo && (
          <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 2 }}>
            {item.subtitulo}
          </div>
        )}
      </div>
      <div className="mono" style={{ fontSize: 13, flexShrink: 0 }}>
        {formatEUR(item.importe)}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// MobilePricePanel — barra inferior compacta (52px), siempre visible.
// Toca para expandir y ver el desglose completo.
// ─────────────────────────────────────────────────────────────────
function MobilePricePanel({ config }) {
  const { total, desglose } = useMemoP(() => calcularEstimacion(config), [config]);
  const [open, setOpen] = useStateP(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        style={{
          position: "fixed",
          left: 0,
          right: 0,
          bottom: 0,
          height: 52,
          background: "var(--surface)",
          borderTop: "1px solid var(--border-soft)",
          zIndex: 50,
          padding: "0 20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          boxShadow: "0 -1px 0 rgba(0,0,0,0.04)",
          width: "100%",
          textAlign: "left",
        }}
        className="show-mobile"
        aria-label="Ver desglose del precio"
      >
        <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
          <span className="eyebrow" style={{ fontSize: 10 }}>Total</span>
          <span className="display" style={{ fontSize: 22, lineHeight: 1, letterSpacing: "-0.02em" }}>
            {formatEUR(total, { decimals: 0 })}
            <span style={{ fontSize: "65%", color: "var(--text-muted)", marginLeft: 2 }}>€</span>
          </span>
        </div>
        <span
          style={{
            fontSize: 11,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            color: "var(--text-muted)",
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          Desglose
          <span aria-hidden style={{ fontSize: 14 }}>↑</span>
        </span>
      </button>

      {open && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(29,29,31,0.4)",
            zIndex: 60,
            display: "flex",
            alignItems: "flex-end",
            animation: "fadeIn 200ms ease",
          }}
          className="show-mobile"
          onClick={() => setOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              background: "var(--background)",
              width: "100%",
              maxHeight: "85vh",
              overflowY: "auto",
              animation: "slideUp 280ms cubic-bezier(0.4, 0, 0.2, 1)",
              padding: "16px 20px 32px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 8 }}>
              <button
                onClick={() => setOpen(false)}
                style={{
                  fontSize: 12,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  color: "var(--text-muted)",
                  padding: "8px 4px",
                }}
              >
                Cerrar ✕
              </button>
            </div>
            <PricePanel config={config} layout="modal" />
          </div>
        </div>
      )}
    </>
  );
}

Object.assign(window, { PricePanel, MobilePricePanel });
