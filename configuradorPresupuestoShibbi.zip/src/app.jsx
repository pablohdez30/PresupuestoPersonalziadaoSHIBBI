// ─────────────────────────────────────────────────────────────────
// App principal — header, hero, layout 2-col (contenido + panel),
// indicador de progreso, pantalla de confirmación, Tweaks.
// ─────────────────────────────────────────────────────────────────

const { useState: useStateA, useEffect: useEffectA, useRef: useRefA, useMemo: useMemoA } = React;

const TWEAK_DEFAULTS = JSON.parse(
  document.getElementById("tweaks-defaults").textContent.replace("/*EDITMODE-BEGIN*/", "").replace("/*EDITMODE-END*/", "")
);

function Header() {
  return (
    <header
      style={{
        position: "sticky",
        top: 0,
        zIndex: 40,
        background: "rgba(250,250,250,0.92)",
        backdropFilter: "saturate(180%) blur(12px)",
        WebkitBackdropFilter: "saturate(180%) blur(12px)",
        borderBottom: "1px solid var(--border-soft)",
        height: 64,
      }}
    >
      <Container
        style={{
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div
          className="display"
          style={{
            fontSize: 22,
            fontWeight: 400,
            letterSpacing: "-0.01em",
          }}
        >
          Shibbi
        </div>
        <div className="eyebrow hide-mobile">Presupuesto a medida</div>
      </Container>
    </header>
  );
}

function Hero({ variant = "type-only" }) {
  if (variant === "with-image") {
    return (
      <section style={{ paddingTop: 80 }}>
        <Container>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 64,
              alignItems: "end",
            }}
            className="hero-grid"
          >
            <div>
              <h1
                className="display"
                style={{
                  fontSize: "clamp(48px, 7vw, 88px)",
                  lineHeight: 0.98,
                  letterSpacing: "-0.03em",
                  marginBottom: 32,
                }}
              >
                Diseña tu mueble.
                <br />
                A medida.
              </h1>
              <p
                style={{
                  fontSize: 19,
                  color: "var(--text-muted)",
                  maxWidth: 460,
                  lineHeight: 1.45,
                  marginBottom: 56,
                }}
              >
                Elige el material, las medidas y el acabado. Te damos una estimación al instante.
              </p>
            </div>
            <MaterialImage label="MESA · ROBLE MACIZO" ratio="1 / 1" />
          </div>
        </Container>
      </section>
    );
  }

  return (
    <section style={{ paddingTop: 120, paddingBottom: 96 }}>
      <Container>
        <h1
          className="display"
          style={{
            fontSize: "clamp(56px, 8vw, 104px)",
            lineHeight: 0.98,
            letterSpacing: "-0.03em",
            marginBottom: 40,
            textWrap: "balance",
          }}
        >
          Diseña tu mueble.
          <br />
          A medida.
        </h1>
        <p
          style={{
            fontSize: 20,
            color: "var(--text-muted)",
            maxWidth: 520,
            lineHeight: 1.45,
          }}
        >
          Elige el material, las medidas y el acabado.
          <br />
          Te damos una estimación al instante.
        </p>
      </Container>
    </section>
  );
}

// ───────── Indicador de progreso fino, lateral derecho ─────────
function ProgressRail({ active }) {
  const steps = [
    { id: 1, label: "Categoría" },
    { id: 2, label: "Material" },
    { id: 3, label: "Patas" },
    { id: 4, label: "Medidas" },
    { id: 5, label: "Acabado" },
    { id: 6, label: "Datos" },
  ];
  return (
    <div
      className="progress-rail hide-mobile"
      style={{
        position: "fixed",
        left: 24,
        top: "50%",
        transform: "translateY(-50%)",
        zIndex: 30,
        display: "flex",
        flexDirection: "column",
        gap: 18,
      }}
    >
      {steps.map((s) => {
        const isActive = active === s.id;
        const isPast = active > s.id;
        return (
          <a
            href={`#sec-${s.id}`}
            key={s.id}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              fontSize: 11,
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              color: isActive ? "var(--text)" : "var(--text-muted)",
              opacity: isActive ? 1 : isPast ? 0.7 : 0.45,
              transition: "all 200ms ease",
            }}
          >
            <span
              style={{
                display: "inline-block",
                width: isActive ? 24 : 12,
                height: 1,
                background: "var(--text)",
                transition: "width 200ms ease",
              }}
            />
            <span className="mono" style={{ fontSize: 11 }}>
              0{s.id}
            </span>
            {isActive && <span>{s.label}</span>}
          </a>
        );
      })}
    </div>
  );
}

function ConfirmationScreen({ onReset }) {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "120px 24px",
        animation: "fadeIn 400ms ease",
      }}
    >
      <div style={{ textAlign: "center", maxWidth: 560 }}>
        <div className="eyebrow" style={{ marginBottom: 32 }}>
          Solicitud enviada
        </div>
        <h2
          className="display"
          style={{
            fontSize: "clamp(48px, 7vw, 88px)",
            lineHeight: 1,
            letterSpacing: "-0.03em",
            marginBottom: 32,
          }}
        >
          Recibido.
        </h2>
        <p
          style={{
            fontSize: 19,
            color: "var(--text-muted)",
            lineHeight: 1.5,
            marginBottom: 64,
          }}
        >
          Te respondemos en menos de 24 horas
          <br />
          con el presupuesto cerrado.
        </p>
        <div
          style={{
            width: 80,
            height: 1,
            background: "var(--border)",
            margin: "0 auto 48px",
          }}
        />
        <p style={{ fontSize: 15, color: "var(--text-muted)", marginBottom: 8 }}>
          Mientras tanto, sígueme el rollo en Instagram.
        </p>
        <p className="display" style={{ fontSize: 28 }}>
          @shibbishop
        </p>
        <button
          onClick={onReset}
          style={{
            marginTop: 64,
            fontSize: 12,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            color: "var(--text-muted)",
            borderBottom: "1px solid var(--border)",
            paddingBottom: 4,
          }}
        >
          Empezar otra solicitud
        </button>
      </div>
    </div>
  );
}

// ───────── App ─────────
function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tweaksOpen, setTweaksOpen] = useStateA(false);

  const [config, setConfig] = useStateA({
    tipo: "mesa",
    material_id: "roble",
    grosor: 5,
    medidas: { largo: 150, ancho: 80, alto: 75 },
    componentes: [{ id: "hairpin", cantidad: 4 }],
    acabado_id: "aceite",
    servicios_ids: [],
    nombre: "",
    email: "",
    telefono: "",
    canal_preferido: "email",
    notas_adicionales: "",
    imagenes: [],
  });

  const update = (partial) => setConfig((c) => ({ ...c, ...partial }));

  const [errors, setErrors] = useStateA({});
  const [submitting, setSubmitting] = useStateA(false);
  const [submitted, setSubmitted] = useStateA(false);

  // Active section tracking
  const [activeStep, setActiveStep] = useStateA(1);
  useEffectA(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) {
          const id = visible.target.id;
          const m = id?.match(/sec-(\d+)/);
          if (m) setActiveStep(parseInt(m[1], 10));
        }
      },
      { rootMargin: "-30% 0px -50% 0px", threshold: [0, 0.25, 0.5, 0.75, 1] }
    );
    document.querySelectorAll("[id^='sec-']").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  // Density
  useEffectA(() => {
    const root = document.documentElement;
    if (tweaks.density === "comfortable") {
      root.style.setProperty("--section-spacing", "96px");
    } else if (tweaks.density === "spacious") {
      root.style.setProperty("--section-spacing", "128px");
    } else {
      root.style.setProperty("--section-spacing", "160px");
    }
  }, [tweaks.density]);

  useEffectA(() => {
    const root = document.documentElement;
    root.style.setProperty(
      "--display",
      `"${tweaks.displayFont}", Georgia, serif`
    );
  }, [tweaks.displayFont]);

  // Body class según layout del panel
  useEffectA(() => {
    document.body.classList.toggle("has-right-panel", tweaks.panelLayout === "right-sticky");
    document.body.classList.toggle("has-bottom-bar", tweaks.panelLayout === "bottom-bar");
  }, [tweaks.panelLayout]);

  function validate() {
    const e = {};
    if (!config.nombre?.trim()) e.nombre = "Indícanos cómo te llamas.";
    if (!config.email?.trim()) e.email = "Necesitamos un email para responderte.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(config.email))
      e.email = "Revisa el formato del email.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function onSubmit() {
    if (!validate()) {
      // Scroll a sec-6
      document.getElementById("sec-6")?.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 1200);
  }

  function reset() {
    setSubmitted(false);
    window.scrollTo({ top: 0 });
  }

  if (submitted) {
    return (
      <>
        <Header />
        <ConfirmationScreen onReset={reset} />
      </>
    );
  }

  return (
    <>
      <Header />
      {tweaks.showProgress && <ProgressRail active={activeStep} />}
      <Hero variant={tweaks.heroVariant} />

      <Container>
        <div className={`layout-grid panel-${tweaks.panelLayout}`}>
          <main className="content-col" style={{ minWidth: 0 }}>
            <div id="sec-1"><CategoriaSection config={config} update={update} /></div>
            <div id="sec-2"><MaterialSection config={config} update={update} /></div>
            <div id="sec-3"><PatasSection config={config} update={update} /></div>
            <div id="sec-4"><MedidasSection config={config} update={update} /></div>
            <div id="sec-5"><AcabadoSection config={config} update={update} /></div>
            <div id="sec-6">
              <DatosSection
                config={config}
                update={update}
                errors={errors}
                onSubmit={onSubmit}
                submitting={submitting}
              />
            </div>
          </main>

        </div>
      </Container>

      {tweaks.panelLayout === "right-sticky" && (
        <aside className="price-col-fixed hide-mobile">
          <PricePanel config={config} layout={tweaks.panelLayout} />
        </aside>
      )}

      {tweaks.panelLayout === "bottom-bar" && (
        <div className="hide-mobile" style={{ position: "fixed", left: 0, right: 0, bottom: 0, zIndex: 30 }}>
          <BottomBarPanel config={config} />
        </div>
      )}

      <MobilePricePanel config={config} />

      <footer
        style={{
          borderTop: "1px solid var(--border-soft)",
          padding: "48px 0 96px",
          marginTop: 96,
          marginBottom: 80, // espacio para barra mobile
        }}
      >
        <Container>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 16 }}>
            <div className="display" style={{ fontSize: 18 }}>Shibbi</div>
            <div style={{ fontSize: 12, color: "var(--text-muted)", letterSpacing: "0.04em" }}>
              shibbishop.com · Taller en España
            </div>
          </div>
        </Container>
      </footer>

      <TweaksPanel
        open={tweaksOpen}
        onOpenChange={setTweaksOpen}
        title="Tweaks"
      >
        <TweakSection title="Tipografía">
          <TweakRadio
            label="Display font"
            value={tweaks.displayFont}
            onChange={(v) => setTweak("displayFont", v)}
            options={[
              { value: "Fraunces", label: "Fraunces" },
              { value: "Cormorant Garamond", label: "Cormorant" },
              { value: "Playfair Display", label: "Playfair" },
            ]}
          />
        </TweakSection>
        <TweakSection title="Densidad">
          <TweakRadio
            label="Espaciado vertical"
            value={tweaks.density}
            onChange={(v) => setTweak("density", v)}
            options={[
              { value: "comfortable", label: "Cómoda" },
              { value: "spacious", label: "Aireada" },
              { value: "expansive", label: "Editorial" },
            ]}
          />
        </TweakSection>
        <TweakSection title="Layout">
          <TweakRadio
            label="Panel de precio (desktop)"
            value={tweaks.panelLayout}
            onChange={(v) => setTweak("panelLayout", v)}
            options={[
              { value: "right-sticky", label: "Lateral" },
              { value: "bottom-bar", label: "Banda" },
            ]}
          />
          <TweakRadio
            label="Hero"
            value={tweaks.heroVariant}
            onChange={(v) => setTweak("heroVariant", v)}
            options={[
              { value: "type-only", label: "Solo tipografía" },
              { value: "with-image", label: "Con imagen" },
            ]}
          />
          <TweakToggle
            label="Indicador de progreso"
            checked={tweaks.showProgress}
            onChange={(v) => setTweak("showProgress", v)}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

// Variante "banda inferior" — barra horizontal pegada al viewport bottom
function BottomBarPanel({ config }) {
  const { total, desglose } = useMemoA(() => calcularEstimacion(config), [config]);
  return (
    <div
      style={{
        background: "var(--surface)",
        borderTop: "1px solid var(--border-soft)",
        boxShadow: "0 -1px 0 rgba(0,0,0,0.04)",
        padding: "20px 0",
      }}
    >
      <Container
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 24,
        }}
      >
        <div style={{ display: "flex", alignItems: "baseline", gap: 32, minWidth: 0, overflow: "hidden" }}>
          <div className="eyebrow" style={{ flexShrink: 0 }}>Tu mueble</div>
          <div
            style={{
              display: "flex",
              gap: 24,
              overflow: "hidden",
              whiteSpace: "nowrap",
              fontSize: 13,
              color: "var(--text-muted)",
            }}
          >
            {desglose.length === 0 && <span>Empieza a configurar.</span>}
            {desglose.slice(0, 4).map((it) => (
              <span key={it.id}>
                {it.titulo}{" "}
                <span className="mono" style={{ color: "var(--text)" }}>{formatEUR(it.importe)}</span>
              </span>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 16, flexShrink: 0 }}>
          <div className="eyebrow">Estimación</div>
          <div className="display" style={{ fontSize: 32, lineHeight: 1 }}>
            {formatEUR(total, { decimals: 0 })}{" "}
            <span style={{ fontSize: "60%", color: "var(--text-muted)" }}>€</span>
          </div>
        </div>
      </Container>
    </div>
  );
}

// ───────── Estilos globales adicionales ─────────
const styleEl = document.createElement("style");
styleEl.textContent = `
@keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
@keyframes slideUp { from { transform: translateY(100%); } to { transform: none; } }

.layout-grid {
  display: block;
}
/* En right-sticky reservamos espacio a la derecha para que el panel
   fixed no se solape con el contenido */
body.has-right-panel .layout-grid.panel-right-sticky {
  padding-right: 380px;
}
body.has-bottom-bar .layout-grid.panel-bottom-bar {
  max-width: 1100px;
  margin: 0 auto;
  padding-bottom: 24px;
}

/* Panel fijo lateral derecho — siempre visible al hacer scroll */
.price-col-fixed {
  position: fixed;
  top: 88px;                    /* bajo el header sticky de 64px + 24 */
  right: 32px;
  width: 340px;
  max-height: calc(100vh - 112px);
  overflow-y: auto;
  z-index: 25;
}
/* Scrollbar discreta */
.price-col-fixed::-webkit-scrollbar { width: 4px; }
.price-col-fixed::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

.material-split { display: flex; gap: 64px; align-items: flex-start; }
.cat-grid { grid-template-columns: repeat(4, 1fr); }
.medidas-grid { grid-template-columns: repeat(3, 1fr); }
.hide-mobile { display: initial; }
.show-mobile { display: none; }

@media (max-width: 1100px) {
  body.has-right-panel .layout-grid.panel-right-sticky { padding-right: 0; }
  .price-col-fixed { display: none; }
}

@media (max-width: 900px) {
  :root { --side-pad: 28px; --section-spacing: 80px; }
  .cat-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 16px !important; }
  .material-split { flex-direction: column; gap: 40px; }
  .medidas-grid { grid-template-columns: 1fr !important; gap: 32px !important; }
  .hide-mobile { display: none !important; }
  .show-mobile { display: flex !important; }
  body { padding-bottom: 64px; }
}

@media (max-width: 540px) {
  .cat-grid { grid-template-columns: 1fr !important; }
}

.progress-rail a:hover { opacity: 1 !important; color: var(--text) !important; }
`;
document.head.appendChild(styleEl);

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
