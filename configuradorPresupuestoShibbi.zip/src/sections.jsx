// ─────────────────────────────────────────────────────────────────
// Las 6 secciones del configurador. Cada una recibe el `config`
// global y un `update(partial)` para escribir.
// ─────────────────────────────────────────────────────────────────

const { useState: useStateS, useEffect: useEffectS, useMemo: useMemoS } = React;

// ───────────────────────── 01 — Categoría ────────────────────────
function CategoriaSection({ config, update }) {
  return (
    <Section index={1} eyebrow="Empieza por aquí" question="¿Qué quieres construir?">
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 24,
        }}
        className="cat-grid"
        role="radiogroup"
        aria-label="Categoría"
      >
        {CATEGORIAS.map((cat) => {
          const selected = config.tipo === cat.id;
          return (
            <button
              key={cat.id}
              role="radio"
              aria-checked={selected}
              onClick={() => update({ tipo: cat.id })}
              style={{
                textAlign: "left",
                padding: 0,
                background: selected ? "var(--accent-bg)" : "var(--surface)",
                border: `1px solid ${selected ? "var(--text)" : "var(--border-soft)"}`,
                borderRadius: 0,
                transition: "border-color 150ms ease, background 150ms ease",
                display: "block",
              }}
              onMouseEnter={(e) => {
                if (!selected) e.currentTarget.style.borderColor = "var(--border)";
              }}
              onMouseLeave={(e) => {
                if (!selected) e.currentTarget.style.borderColor = "var(--border-soft)";
              }}
            >
              <MaterialImage label={cat.placeholder} ratio="4 / 3" />
              <div
                style={{
                  padding: "20px 20px 24px",
                  borderTop: "1px solid var(--border-soft)",
                }}
              >
                <div
                  className="display"
                  style={{ fontSize: 24, marginBottom: 4, letterSpacing: "-0.01em" }}
                >
                  {cat.nombre}
                </div>
                <div style={{ fontSize: 14, color: "var(--text-muted)", marginBottom: 14 }}>
                  {cat.descripcion}
                </div>
                <div className="mono" style={{ fontSize: 13, color: "var(--text-muted)" }}>
                  {cat.desde ? `Desde ${cat.desde} €` : "A consultar"}
                </div>
              </div>
            </button>
          );
        })}
      </div>
      {config.tipo && config.tipo !== "mesa" && (
        <div
          style={{
            marginTop: 32,
            padding: "20px 24px",
            background: "var(--accent-bg)",
            fontSize: 14,
            color: "var(--text-muted)",
            maxWidth: 640,
          }}
        >
          Has seleccionado <strong style={{ color: "var(--text)" }}>{
            CATEGORIAS.find((c) => c.id === config.tipo)?.nombre
          }</strong>. El flujo guiado completo está disponible para mesa. Puedes seguir
          leyendo y enviarnos tus medidas en el último paso — te respondemos a medida.
        </div>
      )}
    </Section>
  );
}

// ───────────────────────── 02 — Material ─────────────────────────
function MaterialSection({ config, update }) {
  const aplicables = MATERIALES.filter((m) =>
    config.tipo ? m.aplicable_a.includes(config.tipo) : true
  );
  const selected = MATERIALES.find((m) => m.id === config.material_id);
  const showImg = selected || aplicables[0];

  // Cross-fade
  const [displayed, setDisplayed] = useStateS(showImg);
  const [fade, setFade] = useStateS(1);
  useEffectS(() => {
    if (showImg && showImg.id !== displayed?.id) {
      setFade(0);
      const t = setTimeout(() => {
        setDisplayed(showImg);
        setFade(1);
      }, 180);
      return () => clearTimeout(t);
    }
  }, [showImg?.id]);

  return (
    <Section index={2} eyebrow="El material" question="Elige la madera o el tablero.">
      <div className="material-split">
        <div style={{ flex: "1 1 50%", minWidth: 0 }}>
          <div
            style={{
              opacity: fade,
              transition: "opacity 250ms ease",
              width: "100%",
            }}
          >
            <MaterialImage label={displayed?.placeholder || ""} ratio="4 / 5" />
          </div>
        </div>

        <div style={{ flex: "1 1 50%", minWidth: 0 }}>
          <div
            role="radiogroup"
            aria-label="Material"
            style={{ borderTop: "1px solid var(--border-soft)" }}
          >
            {aplicables.map((m) => {
              const sel = config.material_id === m.id;
              return (
                <button
                  key={m.id}
                  role="radio"
                  aria-checked={sel}
                  onClick={() =>
                    update({
                      material_id: m.id,
                      grosor: m.grosor_opciones.includes(config.grosor)
                        ? config.grosor
                        : m.grosor_opciones[0],
                    })
                  }
                  style={{
                    width: "100%",
                    padding: "20px 0",
                    borderBottom: "1px solid var(--border-soft)",
                    background: "transparent",
                    textAlign: "left",
                    display: "flex",
                    alignItems: "baseline",
                    justifyContent: "space-between",
                    gap: 16,
                  }}
                >
                  <div style={{ minWidth: 0 }}>
                    <div
                      style={{
                        fontSize: 18,
                        fontWeight: 400,
                        textDecoration: sel ? "underline" : "none",
                        textUnderlineOffset: 6,
                        textDecorationThickness: 1,
                        color: sel ? "var(--text)" : "var(--text)",
                      }}
                    >
                      {m.nombre}
                    </div>
                    <div
                      style={{
                        fontSize: 13,
                        color: "var(--text-muted)",
                        marginTop: 4,
                      }}
                    >
                      {m.descripcion}
                    </div>
                  </div>
                  <div
                    className="mono"
                    style={{ fontSize: 14, color: "var(--text-muted)", flexShrink: 0 }}
                  >
                    {m.precio_m2} €/m²
                  </div>
                </button>
              );
            })}
          </div>

          {/* Grosor */}
          {selected && (
            <div style={{ marginTop: 40 }}>
              <div className="eyebrow" style={{ marginBottom: 16 }}>
                Grosor
              </div>
              <div style={{ display: "flex", gap: 0, alignItems: "stretch" }}>
                {selected.grosor_opciones.map((g, i) => {
                  const sel = config.grosor === g;
                  return (
                    <button
                      key={g}
                      onClick={() => update({ grosor: g })}
                      style={{
                        flex: 1,
                        padding: "14px 0",
                        background: "transparent",
                        borderBottom: `1px solid ${
                          sel ? "var(--text)" : "var(--border-soft)"
                        }`,
                        borderLeft: i === 0 ? 0 : "1px solid var(--border-soft)",
                        fontSize: 16,
                        color: sel ? "var(--text)" : "var(--text-muted)",
                        fontWeight: sel ? 500 : 400,
                        transition: "all 150ms ease",
                      }}
                    >
                      {g} cm
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </Section>
  );
}

// ───────────────────────── 03 — Patas ────────────────────────────
function PatasSection({ config, update }) {
  const patas = COMPONENTES.filter((c) => c.categoria === "pata");
  const sel = config.componentes?.[0];
  const selectedComp = sel ? patas.find((p) => p.id === sel.id) : null;
  const displayed = selectedComp || patas[0];

  const [shown, setShown] = useStateS(displayed);
  const [fade, setFade] = useStateS(1);
  useEffectS(() => {
    if (displayed && displayed.id !== shown?.id) {
      setFade(0);
      const t = setTimeout(() => {
        setShown(displayed);
        setFade(1);
      }, 180);
      return () => clearTimeout(t);
    }
  }, [displayed?.id]);

  function selectPata(pata) {
    update({
      componentes: [{ id: pata.id, cantidad: pata.unidad_default }],
    });
  }
  function setCantidad(n) {
    if (!sel) return;
    update({ componentes: [{ ...sel, cantidad: n }] });
  }

  return (
    <Section index={3} eyebrow="Las patas" question="Cómo se sostiene.">
      <div className="material-split">
        <div style={{ flex: "1 1 50%", minWidth: 0 }}>
          <div style={{ opacity: fade, transition: "opacity 250ms ease" }}>
            <MaterialImage label={shown?.placeholder || ""} ratio="4 / 5" />
          </div>
        </div>
        <div style={{ flex: "1 1 50%", minWidth: 0 }}>
          <div role="radiogroup" style={{ borderTop: "1px solid var(--border-soft)" }}>
            {patas.map((p) => {
              const isSel = sel?.id === p.id;
              return (
                <button
                  key={p.id}
                  role="radio"
                  aria-checked={isSel}
                  onClick={() => selectPata(p)}
                  style={{
                    width: "100%",
                    padding: "20px 0",
                    borderBottom: "1px solid var(--border-soft)",
                    background: "transparent",
                    textAlign: "left",
                    display: "flex",
                    alignItems: "baseline",
                    justifyContent: "space-between",
                    gap: 16,
                  }}
                >
                  <div style={{ minWidth: 0 }}>
                    <div
                      style={{
                        fontSize: 18,
                        textDecoration: isSel ? "underline" : "none",
                        textUnderlineOffset: 6,
                        textDecorationThickness: 1,
                      }}
                    >
                      {p.nombre}
                    </div>
                    <div style={{ fontSize: 13, color: "var(--text-muted)", marginTop: 4 }}>
                      {p.descripcion}
                    </div>
                  </div>
                  <div className="mono" style={{ fontSize: 14, color: "var(--text-muted)" }}>
                    {p.precio_unidad} €/ud
                  </div>
                </button>
              );
            })}
          </div>

          {selectedComp && sel && (
            <div style={{ marginTop: 40 }}>
              <div className="eyebrow" style={{ marginBottom: 16 }}>
                Cantidad
              </div>
              <div style={{ display: "flex" }}>
                {selectedComp.unidad_opciones.map((u, i) => {
                  const isSel = sel.cantidad === u;
                  return (
                    <button
                      key={u}
                      onClick={() => setCantidad(u)}
                      style={{
                        flex: 1,
                        padding: "14px 0",
                        background: "transparent",
                        borderBottom: `1px solid ${
                          isSel ? "var(--text)" : "var(--border-soft)"
                        }`,
                        borderLeft: i === 0 ? 0 : "1px solid var(--border-soft)",
                        fontSize: 16,
                        color: isSel ? "var(--text)" : "var(--text-muted)",
                        fontWeight: isSel ? 500 : 400,
                      }}
                    >
                      {u} ud
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </Section>
  );
}

// ───────────────────────── 04 — Medidas ──────────────────────────
function MedidasSection({ config, update }) {
  const m = config.medidas || {};
  const setM = (k, v) => {
    const num = v === "" ? "" : Math.max(0, parseInt(v, 10) || 0);
    update({ medidas: { ...m, [k]: num } });
  };

  const m2 = useMemoS(() => {
    const l = (m.largo || 0) / 100;
    const a = (m.ancho || 0) / 100;
    return l * a;
  }, [m.largo, m.ancho]);

  return (
    <Section
      index={4}
      eyebrow="Las medidas"
      question="Las medidas exactas."
      lead="Indícalas en centímetros. Si dudas, lo ajustamos contigo después."
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 48,
          maxWidth: 880,
        }}
        className="medidas-grid"
      >
        <LineInput
          label="Largo"
          value={m.largo}
          onChange={(v) => setM("largo", v)}
          inputMode="numeric"
          suffix="cm"
          placeholder="150"
        />
        <LineInput
          label="Ancho"
          value={m.ancho}
          onChange={(v) => setM("ancho", v)}
          inputMode="numeric"
          suffix="cm"
          placeholder="80"
        />
        <LineInput
          label="Alto"
          value={m.alto}
          onChange={(v) => setM("alto", v)}
          inputMode="numeric"
          suffix="cm"
          placeholder="75"
        />
      </div>
      <div
        className="mono"
        style={{
          fontSize: 14,
          color: "var(--text-muted)",
          marginTop: 32,
          letterSpacing: "0.01em",
        }}
      >
        {m2 > 0 ? `${m2.toFixed(2).replace(".", ",")} m² de superficie` : "—"}
      </div>
    </Section>
  );
}

// ───────────────────────── 05 — Acabado y servicios ──────────────
function AcabadoSection({ config, update }) {
  const setAcabado = (id) => update({ acabado_id: config.acabado_id === id ? null : id });
  const toggleServicio = (id) => {
    const cur = config.servicios_ids || [];
    update({
      servicios_ids: cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id],
    });
  };

  return (
    <Section index={5} eyebrow="El acabado" question="Cómo se trata la madera.">
      <div style={{ borderTop: "1px solid var(--border-soft)", maxWidth: 880 }}>
        {ACABADOS.map((a) => {
          const sel = config.acabado_id === a.id;
          return (
            <button
              key={a.id}
              onClick={() => setAcabado(a.id)}
              role="radio"
              aria-checked={sel}
              style={{
                width: "100%",
                padding: "22px 0",
                borderBottom: "1px solid var(--border-soft)",
                background: "transparent",
                textAlign: "left",
                display: "flex",
                alignItems: "center",
                gap: 20,
              }}
            >
              <RadioCircle checked={sel} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 17, fontWeight: 400 }}>{a.nombre}</div>
              </div>
              <div
                style={{
                  fontSize: 14,
                  color: "var(--text-muted)",
                  flex: "0 1 320px",
                  display: "block",
                }}
                className="hide-mobile"
              >
                {a.descripcion}
              </div>
              <div
                className="mono"
                style={{ fontSize: 14, color: "var(--text-muted)", flexShrink: 0, minWidth: 70, textAlign: "right" }}
              >
                {a.precio} €
              </div>
            </button>
          );
        })}
      </div>

      <div style={{ marginTop: 80 }}>
        <div className="eyebrow" style={{ marginBottom: 24 }}>
          Servicios
        </div>
        <div style={{ borderTop: "1px solid var(--border-soft)", maxWidth: 880 }}>
          {SERVICIOS.map((s) => {
            const checked = (config.servicios_ids || []).includes(s.id);
            return (
              <div
                key={s.id}
                style={{
                  padding: "20px 0",
                  borderBottom: "1px solid var(--border-soft)",
                  display: "flex",
                  alignItems: "center",
                  gap: 20,
                }}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 17 }}>{s.nombre}</div>
                  <div style={{ fontSize: 13, color: "var(--text-muted)", marginTop: 4 }}>
                    {s.descripcion}
                  </div>
                </div>
                <div
                  className="mono"
                  style={{ fontSize: 14, color: "var(--text-muted)", minWidth: 60, textAlign: "right" }}
                >
                  {s.precio} €
                </div>
                <Switch
                  checked={checked}
                  onChange={() => toggleServicio(s.id)}
                  label={s.nombre}
                />
              </div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}

// ───────────────────────── 06 — Datos ────────────────────────────
function DatosSection({ config, update, errors, onSubmit, submitting }) {
  const [drag, setDrag] = useStateS(false);
  const setField = (k, v) => update({ [k]: v });

  function onFiles(files) {
    const arr = Array.from(files || []).slice(0, 5);
    update({ imagenes: arr.map((f) => f.name) });
  }

  return (
    <Section
      index={6}
      eyebrow="Cuéntanos quién eres"
      question="Tus datos."
      lead="Te respondemos por email en menos de 24 horas con el presupuesto cerrado."
    >
      <div style={{ maxWidth: 720, display: "flex", flexDirection: "column", gap: 48 }}>
        <LineInput
          label="Nombre"
          value={config.nombre}
          onChange={(v) => setField("nombre", v)}
          error={errors.nombre}
          placeholder="Pablo Hernández"
          required
          name="nombre"
        />
        <LineInput
          label="Email"
          type="email"
          value={config.email}
          onChange={(v) => setField("email", v)}
          error={errors.email}
          placeholder="pablo@correo.com"
          required
          name="email"
        />
        <LineInput
          label="Teléfono (opcional)"
          value={config.telefono}
          onChange={(v) => setField("telefono", v)}
          inputMode="tel"
          placeholder="+34 600 000 000"
          name="telefono"
        />

        <div style={{ marginTop: 16 }}>
          <div className="eyebrow" style={{ marginBottom: 14 }}>
            Canal preferido
          </div>
          <div style={{ display: "flex", gap: 0 }}>
            {[
              { id: "email", l: "Email" },
              { id: "whatsapp", l: "WhatsApp" },
              { id: "cualquiera", l: "Cualquiera" },
            ].map((opt, i) => {
              const sel = config.canal_preferido === opt.id;
              return (
                <button
                  key={opt.id}
                  onClick={() => setField("canal_preferido", opt.id)}
                  style={{
                    flex: 1,
                    padding: "14px 0",
                    background: "transparent",
                    borderBottom: `1px solid ${sel ? "var(--text)" : "var(--border-soft)"}`,
                    borderLeft: i === 0 ? 0 : "1px solid var(--border-soft)",
                    fontSize: 15,
                    color: sel ? "var(--text)" : "var(--text-muted)",
                    fontWeight: sel ? 500 : 400,
                  }}
                >
                  {opt.l}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <div className="eyebrow" style={{ marginBottom: 14 }}>
            Notas
          </div>
          <textarea
            value={config.notas_adicionales || ""}
            onChange={(e) => setField("notas_adicionales", e.target.value)}
            placeholder="Cuéntanos cualquier detalle que importe (uso, espacio, fechas…)"
            rows={4}
            style={{
              width: "100%",
              border: 0,
              borderBottom: "1px solid var(--border-soft)",
              background: "transparent",
              fontFamily: "var(--sans)",
              fontSize: 16,
              padding: "12px 0",
              outline: 0,
              resize: "vertical",
              color: "var(--text)",
            }}
          />
        </div>

        <div>
          <div className="eyebrow" style={{ marginBottom: 14 }}>
            Inspiración
          </div>
          <label
            onDragEnter={(e) => {
              e.preventDefault();
              setDrag(true);
            }}
            onDragOver={(e) => e.preventDefault()}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDrag(false);
              onFiles(e.dataTransfer.files);
            }}
            style={{
              display: "block",
              padding: "44px 24px",
              border: `1px dashed ${drag ? "var(--text)" : "var(--border)"}`,
              background: drag ? "var(--accent-bg)" : "transparent",
              textAlign: "center",
              cursor: "pointer",
              transition: "all 150ms ease",
            }}
          >
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              multiple
              hidden
              onChange={(e) => onFiles(e.target.files)}
            />
            <div style={{ fontSize: 15 }}>
              {config.imagenes?.length
                ? `${config.imagenes.length} archivo${config.imagenes.length > 1 ? "s" : ""} seleccionado${
                    config.imagenes.length > 1 ? "s" : ""
                  }`
                : "Arrastra fotos de inspiración aquí"}
            </div>
            <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 8 }}>
              JPG, PNG, WEBP — hasta 5 archivos
            </div>
          </label>
        </div>

        <div style={{ marginTop: 16 }}>
          <PrimaryButton onClick={onSubmit} loading={submitting} full>
            Enviar solicitud
          </PrimaryButton>
          <div
            style={{
              fontSize: 12,
              color: "var(--text-muted)",
              marginTop: 16,
              textAlign: "center",
            }}
          >
            Al enviar aceptas que nos pongamos en contacto contigo.
          </div>
        </div>
      </div>
    </Section>
  );
}

Object.assign(window, {
  CategoriaSection,
  MaterialSection,
  PatasSection,
  MedidasSection,
  AcabadoSection,
  DatosSection,
});
