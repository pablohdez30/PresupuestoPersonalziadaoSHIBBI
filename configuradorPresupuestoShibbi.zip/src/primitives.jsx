const { useState, useRef, useEffect, useMemo, useCallback } = React;

// ─────────────────────────────────────────────────────────────────
// Placeholder de material — cuadrado --accent-bg con nombre en
// mayúsculas espaciadas. Sustituye a las fotos hasta tener fotos
// reales del taller.
// ─────────────────────────────────────────────────────────────────
function MaterialImage({ label, ratio = "1 / 1", style }) {
  return (
    <div
      style={{
        width: "100%",
        aspectRatio: ratio,
        background: "var(--accent-bg)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        overflow: "hidden",
        ...style,
      }}
    >
      {/* Sutil patrón de líneas verticales muy suaves para sugerir la
          dirección de la veta sin recrearla literalmente */}
      <div
        aria-hidden
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "repeating-linear-gradient(90deg, transparent 0 23px, rgba(29,29,31,0.025) 23px 24px)",
          pointerEvents: "none",
        }}
      />
      <span
        style={{
          fontFamily: "var(--sans)",
          fontSize: 12,
          fontWeight: 500,
          letterSpacing: "0.18em",
          textTransform: "uppercase",
          color: "var(--text-muted)",
          position: "relative",
          padding: "0 16px",
          textAlign: "center",
        }}
      >
        {label}
      </span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// Section — eyebrow + question + body. La unidad estructural de
// toda la página.
// ─────────────────────────────────────────────────────────────────
function Section({ index, eyebrow, question, lead, children, id }) {
  const eyebrowText = `${String(index).padStart(2, "0")} — ${eyebrow}`;
  return (
    <section
      id={id}
      data-screen-label={`${String(index).padStart(2, "0")} ${eyebrow}`}
      style={{
        padding: "var(--section-spacing) 0",
        borderTop: "1px solid var(--border-soft)",
      }}
    >
      <div className="eyebrow" style={{ marginBottom: 32 }}>
        {eyebrowText}
      </div>
      <h2
        className="display"
        style={{
          fontSize: "clamp(36px, 4.6vw, 64px)",
          lineHeight: 1.05,
          marginBottom: lead ? 20 : 56,
          maxWidth: 900,
          textWrap: "balance",
        }}
      >
        {question}
      </h2>
      {lead && (
        <p
          style={{
            fontSize: 19,
            color: "var(--text-muted)",
            maxWidth: 560,
            marginBottom: 56,
            lineHeight: 1.45,
          }}
        >
          {lead}
        </p>
      )}
      {children}
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────
// PrimaryButton — único CTA fuerte. Negro sólido, texto blanco.
// ─────────────────────────────────────────────────────────────────
function PrimaryButton({ children, onClick, disabled, loading, full = false, type = "button" }) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      style={{
        background: "var(--text)",
        color: "var(--surface)",
        fontFamily: "var(--sans)",
        fontSize: 16,
        fontWeight: 500,
        padding: "18px 32px",
        borderRadius: 4,
        width: full ? "100%" : "auto",
        opacity: disabled || loading ? 0.6 : 1,
        transition: "opacity 100ms ease",
        letterSpacing: "0.01em",
      }}
      onMouseEnter={(e) => {
        if (!disabled && !loading) e.currentTarget.style.opacity = "0.85";
      }}
      onMouseLeave={(e) => {
        if (!disabled && !loading) e.currentTarget.style.opacity = "1";
      }}
    >
      {loading ? "Enviando…" : children}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────────
// LineInput — input estilo Apple: sin borde, línea inferior, label
// flotante (sube al focus o cuando hay valor).
// ─────────────────────────────────────────────────────────────────
function LineInput({
  label,
  value,
  onChange,
  type = "text",
  suffix,
  placeholder,
  size = "lg",
  error,
  inputMode,
  required,
  name,
}) {
  const [focus, setFocus] = useState(false);
  const filled = value !== undefined && value !== null && String(value).length > 0;
  const floating = focus || filled;

  const heights = { lg: 64, md: 56, sm: 48 };
  const fontSizes = { lg: 28, md: 22, sm: 18 };
  const labelTop = { lg: 22, md: 18, sm: 14 };

  return (
    <div style={{ position: "relative", width: "100%" }}>
      <label
        style={{
          position: "absolute",
          left: 0,
          top: floating ? 0 : labelTop[size],
          fontSize: floating ? 11 : 13,
          fontWeight: 500,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          color: "var(--text-muted)",
          pointerEvents: "none",
          transition: "all 180ms cubic-bezier(0.4, 0, 0.2, 1)",
        }}
      >
        {label}
      </label>

      <div
        style={{
          display: "flex",
          alignItems: "baseline",
          gap: 12,
          paddingTop: 24,
          paddingBottom: 12,
          borderBottom: `1px solid ${
            error ? "var(--error)" : focus ? "var(--text)" : "var(--border-soft)"
          }`,
          minHeight: heights[size],
          transition: "border-color 150ms ease",
        }}
      >
        <input
          name={name}
          type={type}
          value={value ?? ""}
          inputMode={inputMode}
          required={required}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          placeholder={focus ? placeholder : ""}
          style={{
            flex: 1,
            border: 0,
            outline: 0,
            background: "transparent",
            fontFamily: "var(--sans)",
            fontSize: fontSizes[size],
            fontWeight: 400,
            color: "var(--text)",
            padding: 0,
            minWidth: 0,
          }}
        />
        {suffix && (
          <span
            className="mono"
            style={{
              fontSize: 14,
              color: "var(--text-muted)",
              flexShrink: 0,
            }}
          >
            {suffix}
          </span>
        )}
      </div>
      {error && (
        <div
          style={{
            fontSize: 12,
            color: "var(--error)",
            marginTop: 8,
            letterSpacing: "0.02em",
          }}
        >
          {error}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// Switch — toggle estilo Apple, sutil, sin fanfarria.
// ─────────────────────────────────────────────────────────────────
function Switch({ checked, onChange, label }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      style={{
        position: "relative",
        width: 44,
        height: 26,
        borderRadius: 999,
        background: checked ? "var(--text)" : "var(--border)",
        transition: "background 200ms ease",
        flexShrink: 0,
        padding: 0,
      }}
      aria-label={label}
    >
      <span
        style={{
          position: "absolute",
          top: 3,
          left: checked ? 21 : 3,
          width: 20,
          height: 20,
          borderRadius: "50%",
          background: "var(--surface)",
          transition: "left 200ms cubic-bezier(0.4, 0, 0.2, 1)",
          boxShadow: "0 1px 2px rgba(0,0,0,0.1)",
        }}
      />
    </button>
  );
}

// ─────────────────────────────────────────────────────────────────
// RadioCircle — círculo sutil para selección de acabados.
// ─────────────────────────────────────────────────────────────────
function RadioCircle({ checked }) {
  return (
    <span
      aria-hidden
      style={{
        width: 16,
        height: 16,
        borderRadius: "50%",
        border: `1px solid ${checked ? "var(--text)" : "var(--border)"}`,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
        transition: "border-color 150ms ease",
      }}
    >
      {checked && (
        <span
          style={{
            width: 8,
            height: 8,
            borderRadius: "50%",
            background: "var(--text)",
          }}
        />
      )}
    </span>
  );
}

// ─────────────────────────────────────────────────────────────────
// Container — caja máxima de la página, padding lateral.
// ─────────────────────────────────────────────────────────────────
function Container({ children, style }) {
  return (
    <div
      style={{
        maxWidth: "var(--container-max)",
        margin: "0 auto",
        padding: "0 var(--side-pad)",
        width: "100%",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// formatEUR — formato europeo con coma decimal
// ─────────────────────────────────────────────────────────────────
function formatEUR(n, opts = {}) {
  const { decimals = 2 } = opts;
  return Number(n)
    .toFixed(decimals)
    .replace(".", ",")
    .replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

Object.assign(window, {
  MaterialImage,
  Section,
  PrimaryButton,
  LineInput,
  Switch,
  RadioCircle,
  Container,
  formatEUR,
});
